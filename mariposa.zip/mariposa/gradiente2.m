function G = gradiente2( Z )  

dir = [0 0 ; 1 0 ; 1 1 ; 0 1 ; -1 0 ; -1 -1 ; 0 -1 ; 1 -1 ; -1 1 ];

G = cell( size(Z) );

for i=1:size(Z,1)
    for j=1:size(Z,2)
        G{i,j} = zeros( 1 , 9 );
    end
end

for i=1:size(Z,1)
    for j=1:size(Z,2)
        for k = 1:max( size(dir) );
            if ( (i+dir(k,1))>0 )&&( (i+dir(k,1))<=size(Z,1) )&&( (j+dir(k,2))>0 )&&( (j+dir(k,2))<=size(Z,2) ) %si la direccion no se sale de la grilla
                G{i,j}(k) = Z( i+dir(k,1) , j+dir(k,2) );
            else
                G{i,j}(k) = NaN;
            end
        end
        G{i,j} = G{i,j} - min(G{i,j});
        G{i,j}(isnan(G{i,j})) = 0;
        G{i,j} = G{i,j}./sum(G{i,j});
        G{i,j} = cumsum(G{i,j});
    end
end
                    

end

