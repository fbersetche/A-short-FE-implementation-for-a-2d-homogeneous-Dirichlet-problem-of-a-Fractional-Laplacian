h = 1/150;
[X,Y] = meshgrid(0:h:1-h, 0:h:1-h);
Z = -X .* exp(-X.^2 - Y.^2);
%T = load('terreno.txt');
%Z = reshape(T(:,3),150,[]);

R = zeros(size(X));
% surf(X,Y,Z)
% view([0 90])

q = 0;
p = 0.5;
coef = 0.999;
grad = gradiente(Z);
longitudes = zeros(1,10000);

for k=1:10000
    x1 = 75;%ceil(150*rand);
    x2 = 75;%ceil(150*rand);
    M = [x1 x2 q 1 x1-1 x2-1 p];
    longitud = 0;
    while M(4)==1
        M = actualizar(M , grad , size(Z,1) , size(Z,2));
        %R(M(1),M(2)) = R(M(1),M(2)) + 1;
        if R(M(1),M(2))==0
            R(M(1),M(2))=1;
        end
        longitud = longitud + 1;
    end
    longitudes(k)=longitud;
end

R = -R;
R=mat2gray(R, [min(min(R)) max(max(R))]);
imshow(R);

    
    
