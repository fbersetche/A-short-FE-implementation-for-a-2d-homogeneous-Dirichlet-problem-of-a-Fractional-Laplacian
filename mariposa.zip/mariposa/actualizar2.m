function n_M = actualizar2( M , grad , q , coef , lim1 , lim2 ) %coef probabilidad de exito en geometrica

%M = [ x y q v ] 

n_M = M;

dir = [0 0 ; 1 0 ; 1 1 ; 0 1 ; -1 0 ; -1 -1 ; 0 -1 ; 1 -1 ; -1 1 ];

if rand<q;
    
    n_M(1:2) = n_M(1:2) + dir( ceil(9*rand) , : );
    
    %me fijo que no se salga de la grilla
    %%%%%%%%%
    if n_M(1)>lim1
        n_M(1)=lim1;
    end
    if n_M(1)<1
        n_M(1)=1;
    end
    if n_M(2)>lim2
        n_M(2)=lim2;
    end
    if n_M(2)<1
        n_M(2)=1;
    end    
    %%%%%%%%%
else
    
    val = rand;
    if val<=grad{M(1),M(2)}(1)
        n_M(1:2) = n_M(1:2) + dir( 1 , : );
    elseif (grad{M(1),M(2)}(1)<val)&&(val<=grad{M(1),M(2)}(2))
        n_M(1:2) = n_M(1:2) + dir( 2 , : );
    elseif (grad{M(1),M(2)}(2)<val)&&(val<=grad{M(1),M(2)}(3))
        n_M(1:2) = n_M(1:2) + dir( 3 , : );
    elseif (grad{M(1),M(2)}(3)<val)&&(val<=grad{M(1),M(2)}(4))
        n_M(1:2) = n_M(1:2) + dir( 4 , : );
    elseif (grad{M(1),M(2)}(4)<val)&&(val<=grad{M(1),M(2)}(5))
        n_M(1:2) = n_M(1:2) + dir( 5 , : );
    elseif (grad{M(1),M(2)}(5)<val)&&(val<=grad{M(1),M(2)}(6))
        n_M(1:2) = n_M(1:2) + dir( 6 , : );
    elseif (grad{M(1),M(2)}(6)<val)&&(val<=grad{M(1),M(2)}(7))
        n_M(1:2) = n_M(1:2) + dir( 7 , : );
    elseif (grad{M(1),M(2)}(7)<val)&&(val<=grad{M(1),M(2)}(8))
        n_M(1:2) = n_M(1:2) + dir( 8 , : );
    elseif (grad{M(1),M(2)}(8)<val)&&(val<=grad{M(1),M(2)}(9))
        n_M(1:2) = n_M(1:2) + dir( 9 , : );
    end
    
end


%tiempo de vida

if rand>coef
    %n_M(4) = n_M(4) + 1;
    n_M(4) = 0; %muere
end


end

