function n_M = actualizar( M , grad , lim1 , lim2 ) %coef probabilidad de exito en geometrica

%M = [ x y q v ] 
q = M(3);
p = M(7);
n_M = M;

n_M(5:6) = M(1:2);%guardo la posicion anterior

dir = [0 0 ; 1 0 ; 1 1 ; 0 1 ; -1 0 ; -1 -1 ; 0 -1 ; 1 -1 ; -1 1 ];

r = rand;
if r<q;
    n_M(1:2) = n_M(1:2) + dir( ceil(9*rand) , : );
    
    %me fijo que no se salga de la grilla
    %%%%%%%%%
    if n_M(1)>lim1
        n_M(1)=lim1;
    end
    if n_M(1)<1
        n_M(1)=1;
    end
    if n_M(2)>lim2
        n_M(2)=lim2;
    end
    if n_M(2)<1
        n_M(2)=1;
    end    
    %%%%%%%%%
elseif (r>=q)&&(r<p+q)
    d = M(1:2)-M(5:6);
    n_M(1:2) = n_M(1:2) + d;
    
    %me fijo que no se salga de la grilla
    %%%%%%%%%
    if n_M(1)>lim1
        n_M(1)=lim1;
    end
    if n_M(1)<1
        n_M(1)=1;
    end
    if n_M(2)>lim2
        n_M(2)=lim2;
    end
    if n_M(2)<1
        n_M(2)=1;
    end    
    %%%%%%%%%
else
    n_M(1:2) = grad{M(1),M(2)};
end

if (grad{n_M(1),n_M(2)}(1)==n_M(1))&&(grad{n_M(1),n_M(2)}(2)==n_M(2)) %si esta en un maximo
     n_M(4) = 0; %queda inactiva
end


%tiempo de vida

% if rand>coef
%     %n_M(4) = n_M(4) + 1;
%     n_M(4) = 0; %muere
% end


