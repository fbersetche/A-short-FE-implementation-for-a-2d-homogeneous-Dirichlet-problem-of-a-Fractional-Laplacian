function G = gradiente( Z )  %la primera direccion tiene que ser [0 0] sino anda mal (**) 

dir = [0 0 ; 1 0 ; 1 1 ; 0 1 ; -1 0 ; -1 -1 ; 0 -1 ; 1 -1 ; -1 1 ];

G = cell( size(Z) );

for i=1:size(Z,1)
    for j=1:size(Z,2)
        actual = Z(i,j);%(**)
        pos = [0 0];
        for k = 2:max( size(dir) );
            if ( (i+dir(k,1))>0 )&&( (i+dir(k,1))<=size(Z,1) )&&( (j+dir(k,2))>0 )&&( (j+dir(k,2))<=size(Z,2) ) %si la direccion no se sale de la grilla
                if  Z( i+dir(k,1) , j+dir(k,2) ) > actual
                    actual = Z( i+dir(k,1) , j+dir(k,2) );
                    pos = dir(k,:);
                end
            end
        end
        G{i,j}=[i,j] + pos;
    end
end
                    

end

