casos = [50 100 300 500 700 1000 1500 2000 5000];
q_p = zeros(1,100);

for L = 1:100
    L
    correr_4
    q_p(L) = mean( MM(:,3) );
end

mean(q_p)
std(q_p)

hist(q_p,0:0.01:1)
    