h = 1/150;
[X,Y] = meshgrid(0:h:1-h, 0:h:1-h);
%Z = -X .* exp(-X.^2 - Y.^2);
T = load('terreno.txt');
Z = reshape(T(:,3),150,[]);


q = 0.5;
p = 0;
grad = gradiente(Z);

nm = 500; %numero de mariposas
MM = zeros(nm,7);

%MM tiene la siguiente estructura: 
%MM(k,:) = [x actual, y actual, q , estado ,  x anterior , y anterior]
%estado = 1 si esta activa
%       = 0 si esta inactiva (llego a un maximo)
%       = -1 si esta muerta

%fijo posiciones iniciales
for k=1:nm
    x1 = ceil(150*rand);
    x2 = ceil(150*rand);
    MM(k,:) = [x1 x2 q 1 x1 x2 p];
end

%guardo posiciones originales
PO = MM(:,1:2);

%Corro la simulacion hasta que llegan a las posiciones finales
hay_alguna_viva=true;
tiempo = 0;
while hay_alguna_viva
    
    hay_activa = true;
    while hay_activa
        hay_activa = false;
        for k=1:nm
            if MM(k,4)==1 %si esta activa
                MM(k,:) = actualizar(MM(k,:) , grad , size(Z,1) , size(Z,2));
                hay_activa = true;
            end
        end
    end

    %Apareo y quito a las que no se reproducen
    for i=1:size(Z,1)
        for j=1:size(Z,2)
            ind = find( (MM(:,1)==i).*(MM(:,2)==j) );%busco los indices de todas las que estan en la posicion (i,j)
            if ceil(length(ind)/2)~=length(ind)/2 %si es impar remuevo una
                MM(ind(1),4)=-1; %muere
                MM(ind(1),1:2) = [-1 -1]; %tiro el cadaver afuera de la grilla para que no moleste en los calculos
                ind(1) = [];
            end
            MM(ind,1:2)=PO(ind,:); %las que quedan las vuelvo a su posicion original
        end
    end
    
    hay_alguna_viva = sum(MM(:,4)==-1)<nm;
    nm - sum(MM(:,4)==-1)
    tiempo = tiempo + 1
end


% R = R./max(max(R));
% R(R>0.2)=0.2;
%R = -R;
%R=mat2gray(R, [min(min(R)) max(max(R))]);
%imshow(R);

figure
Z=mat2gray(Z, [min(min(Z)) max(max(Z))]);
imshow(Z);


    
    
