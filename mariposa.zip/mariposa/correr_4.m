h = 1/150;
[X,Y] = meshgrid(0:h:1-h, 0:h:1-h);
%Z = -X .* exp(-X.^2 - Y.^2);
T = load('terreno.txt');
Z = reshape(T(:,3),150,[]);


%q = 0.5;
p = 0;
grad = gradiente(Z);

nm = 10; %numero de mariposas
MM = zeros(nm,7);

%MM tiene la siguiente estructura: 
%MM(k,:) = [x actual, y actual, q , estado ,  x anterior , y anterior]
%estado = 1 si esta activa
%       = 0 si esta inactiva (llego a un maximo)
%       = -1 si esta muerta

%fijo posiciones iniciales
for k=1:nm
    x1 = ceil(150*rand);
    x2 = ceil(150*rand);
    q = rand;
    MM(k,:) = [x1 x2 q 1 x1 x2 p];
end

coef = 0.95; %coeficiente de vida
%Corro la simulacion hasta que llegan a las posiciones finales
NN = 5000; %cantidad de ciclos
q_prom = zeros(1,NN);
q_std = zeros(1,NN); 
for N=1:NN
    %N
    q_prom(N) = mean(MM(:,3));
    q_std(N) = std(MM(:,3));
    
    
    %las muevo de posicion
    for k=1:nm
        MM(k,:) = actualizar_tdevida(MM(k,:),coef); %eventualmente muere
        if MM(k,4)==1 %si esta activa
            MM(k,:) = actualizar(MM(k,:) , grad , size(Z,1) , size(Z,2));
        end
    end
    
    for k=1:nm %revivo las muertas
        if MM(k,4)==-1 
                MM(k,1)=ceil(150*rand); %la posicion
                MM(k,2)=ceil(150*rand);
                MM(k,3)=min(MM(:,3)) + (max(MM(:,3)) - min(MM(:,3)))*rand;           %el q
                MM(k,4)=1;              %el estado (activa)
        end
    end
    
    for k=1:nm  %apareo o quito las que llegaron a un maximo (se aparean y mueren)
        if MM(k,4)==0
            %true
            ind = find( (MM(:,1)==MM(k,1).*(MM(:,2)==MM(k,2)) ) );%busco los indices de todas las que estan en la posicion (i,j)
            %ahora apareo las que quedan
            for l=1:2:length(ind)-1
                %true
                q1 = MM(l,3) + (MM(l+1,3) - MM(l,3))*rand; %calculo el nuevo q uniforme entre los q de los padres
                q2 = MM(l,3) + (MM(l+1,3) - MM(l,3))*rand;
                %seteo los valores de los hijos 
                MM(ind(l),1)=ceil(150*rand); %la posicion
                MM(ind(l),2)=ceil(150*rand);
                MM(ind(l),3)=q1;             %el q
                MM(ind(l),4)=1;              %el estado (activa)
                
                MM(ind(l+1),1)=ceil(150*rand); %la posicion
                MM(ind(l+1),2)=ceil(150*rand);
                MM(ind(l+1),3)=q2;             %el q
                MM(ind(l+1),4)=1;              %el estado (activa)
            end
        end
    end
end

%hist(MM(:,3),0:0.01:1)
%figure
%plot(1:NN,q_prom,'-')
%figure
%plot(1:NN,q_std,'-r')


    
    
