function n_M = actualizar_tdevida( M , coef) %coef probabilidad de exito en geometrica

%M = [ x y q v ] 
n_M = M;

if rand>coef
    n_M(4) = -1; %muere
end


