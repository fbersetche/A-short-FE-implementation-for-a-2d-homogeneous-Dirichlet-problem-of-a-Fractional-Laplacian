[X,Y] = meshgrid(-2:.1:2, -2:.1:2);
Z = X .* exp(-X.^2 - Y.^2);
R = zeros(size(X));
surf(X,Y,Z)

q = 0.5;

direccion = [0 0 ; 1 0 ; 1 1 ; 0 1 ; -1 0 ; -1 -1 ; 0 -1 ; 1 -1 ; -1 1 ];

%E_in = [0 0];
E_act = [1 1];

for k = 1:100;
    if rand<q;
        E_act = E_act + direccion( ceil(9*rand) , : );
        E_act = [ mod( E_act(1)-1 , size(X,1)) ,  mod( E_act(1)-1 , size(X,2)) ];
    else
        D = direccion + repmat(E_act,9,1);
        J = max( Z(D(:,1),D(:,2)) );
        E_act = 
    R(E_act) = R(E_act) + 1;
end


surf(X,Y,R)

    
    
